import { useState } from 'react';
import { hello_backend } from 'declarations/hello_backend';


function App() {
  const [greeting, setGreeting] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const name = event.target.elements.name.value;
    hello_backend.greet(name).then((greeting) => {
      setGreeting(greeting);
    });
    return false;
  }

  return (
    <div>
      {/* Navigation Bar */}
      <nav style={styles.navbar}>
        <h1 style={styles.logo}>Kuch Bhii</h1>
        <ul style={styles.navLinks}>
          <li><a href="#home" style={styles.navLink}>Home</a></li>
          <li><a href="#about" style={styles.navLink}>About Us</a></li>
          <li><a href="#contact" style={styles.navLink}>Contact Us</a></li>
        </ul>
      </nav>

      {/* Hero Section */}
      <section id="home" style={styles.hero}>
        <h1>Welcome to Kuch Bhii!</h1>
        <p>We do... Kuch Bhii!</p>
        <form onSubmit={handleSubmit} style={styles.form}>
          <input type="text" name="name" placeholder="Enter your name" style={styles.input} />
          <button type="submit" style={styles.button}>Greet Me!</button>
        </form>
        {greeting && <h2>{greeting}</h2>}
      </section>

      {/* About Us Section */}
      <section id="about" style={styles.about}>
        <h2>About Us</h2>
        <p>At Kuch Bhii, we believe in doing everything and anything. We solve problems, create solutions, and make the world a better place by doing... Kuch Bhii!</p>
      </section>

      {/* Contact Us Section */}
      <section id="contact" style={styles.contact}>
        <h2>Contact Us</h2>
        <p>Have any questions? Feel free to reach out to us at <a href="mailto:contact@kuchbhii.com">contact@kuchbhii.com</a></p>
      </section>

      {/* Footer */}
      <footer style={styles.footer}>
        <p>&copy; 2024 Kuch Bhii. All rights reserved.</p>
      </footer>
    </div>
  );
}

// Simple styles in JavaScript object format
const styles = {
  navbar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px',
    backgroundColor: '#333',
    color: '#fff'
  },
  logo: {
    marginLeft: '10px'
  },
  navLinks: {
    display: 'flex',
    listStyleType: 'none',
  },
  navLink: {
    color: '#fff',
    textDecoration: 'none',
    marginLeft: '20px',
    fontSize: '18px'
  },
  hero: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '60vh',
    background: 'linear-gradient(135deg, #2196f3, #21cbf3)',
    color: '#fff',
    textAlign: 'center',
    padding: '20px'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '20px'
  },
  input: {
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    marginBottom: '10px',
    width: '200px',
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#6200ea',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  about: {
    padding: '50px',
    backgroundColor: '#f4f4f4',
    textAlign: 'center'
  },
  contact: {
    padding: '50px',
    backgroundColor: '#e0e0e0',
    textAlign: 'center'
  },
  footer: {
    padding: '20px',
    backgroundColor: '#333',
    color: '#fff',
    textAlign: 'center',
  }
};

export default App;
